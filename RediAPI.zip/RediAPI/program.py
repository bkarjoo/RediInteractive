from interactive import *
from redi_order_factory import *


if __name__ == "__main__":
    interactive = Interactive()
    interactive.gui_start()

